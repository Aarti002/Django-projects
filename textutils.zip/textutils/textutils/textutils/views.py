#created by me!py

from django.http import HttpResponse
from django.shortcuts import render

def index(request):
    return render(request,'index1.html')

def about(request):
    return HttpResponse("<p>You are at about page!</p> <button ><a href='http://127.0.0.1:8000/'> go back</a></button>")

def txt(request):
    with open('textutils/text.txt') as file:
        return HttpResponse(file.read())


def analyze(request):
    #getting the text/data enter by user through "GET" and performing operation we want
    mail=request.POST.get('email','not_provided')
    text = request.POST.get('data', 'default')
    remove = request.POST.get('removepunc', 'off')
    count = request.POST.get('countcharacter', 'off')
    upp=request.POST.get('upper','off')
    print(text)
    print(remove)
    ans = ""

    punc = "!@#$%^&*()_+:;,./<>?~{}[]\|"
    if remove=="on" and count=="on" and upp=="on":
        x = 0
        for i in text:
            if i not in punc:
                ans += i
                x+=1
        a = ans.upper()
        param = {'email':mail,'purpose': 'Removed puntuation and has been changed into uppercase with character count!', 'analyzed_text': a,'character_count': x}
        return render(request, 'index.html', param)
    elif remove=="on" and count=="on":
        x = 0
        for i in text:
            if i not in punc:
                ans += i
                x += 1
        a=text
        param = {'email':mail,'purpose': 'Removed puntuation and has been removed with character count!',
                 'analyzed_text': a, 'character_count': x}
        return render(request, 'index.html', param)
    elif remove=="on" and upp=="on":

        for i in text:
            if i not in punc:
                ans += i

        a = ans.upper()
        param = {'email':mail,'purpose': 'Removed puntuation and has been changed into uppercase !',
                 'analyzed_text': a}
        return render(request, 'index.html', param)
    elif count=="on" and upp=="on":
        x = 0
        for i in text:
            if i!="\n" and i!=" ":
                x+=1
        a = text.upper()
        param = {'email':mail,'purpose': 'Text has been changed into uppercase with character count!',
                 'analyzed_text': a, 'character_count': x}
        return render(request, 'index.html', param)
    elif remove == "on":
        for i in text:
            if i not in punc:
                ans += i
        param = {'email':mail,'purpose': 'Removed puntuation', 'analyzed_text': ans}
        return render(request, 'index.html', param)
    elif upp=="on":
        a=text.upper()
        param={'email':mail,'function':'Text has been set to uppercase','new_text':a}
        return render(request,'upper.html',param)
    elif count=="on":
        x=0
        for i in text:
            if i!=" " or i!="\n":
                x+=1
        param={'email':mail,'perform':'Number of characters: ','cnt':x}
        return render(request,'count.html',param)
    else:
        return HttpResponse("Error")

